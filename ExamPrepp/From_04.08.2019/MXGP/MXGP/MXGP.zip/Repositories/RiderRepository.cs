﻿using MXGP.Models.Riders;

namespace MXGP.Repositories
{
    public class RiderRepository : Repository<Rider>
    {
        public RiderRepository()
            :base()
        {
        }
    }
}
