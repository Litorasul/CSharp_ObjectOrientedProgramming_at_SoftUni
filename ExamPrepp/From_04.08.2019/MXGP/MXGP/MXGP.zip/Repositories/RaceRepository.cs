﻿using MXGP.Models.Races;

namespace MXGP.Repositories
{
    public class RaceRepository : Repository<Race>
    {
        public RaceRepository()
            :base()
        {
        }
    }
}
