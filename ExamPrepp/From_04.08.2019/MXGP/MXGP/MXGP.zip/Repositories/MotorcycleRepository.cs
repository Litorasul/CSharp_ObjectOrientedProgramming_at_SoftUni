﻿using MXGP.Models.Motorcycles;
using MXGP.Models.Motorcycles.Contracts;

namespace MXGP.Repositories
{
    public class MotorcycleRepository : Repository<Motorcycle>
    {
        public MotorcycleRepository()
            : base()
        {

        }
      
    }
}
