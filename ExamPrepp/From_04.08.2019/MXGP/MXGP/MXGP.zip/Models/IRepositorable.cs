﻿namespace MXGP.Models
{
    public interface IRepositorable
    {
        string Name { get; }
    }
}
